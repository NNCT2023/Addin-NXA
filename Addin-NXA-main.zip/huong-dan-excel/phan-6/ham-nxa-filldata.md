# 📈 Hàm NXA_FillData

## 📌 Cú pháp
`NXA_FillData(rng_existingdata, rng_fill)`

## 🦾 Chức năng
Tự động điền các ô trống dựa vào dữ liệu mẫu đã có.

| Tham số | Mô tả |
|---------|------|
| `rng_existingdata` | Dữ liệu huấn luyện |
| `rng_fill` | Phạm vi cần điền dữ liệu |

📌 **Ví dụ**:
```excel
=NXA_FillData(A2:B10, C2:C10)