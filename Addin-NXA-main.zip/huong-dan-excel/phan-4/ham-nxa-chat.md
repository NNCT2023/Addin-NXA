# 💬 Hàm NXA_Chat

## 📌 Cú pháp
`NXA_Chat()`

## 🦾 Chức năng
Mở khung trò chuyện trực tiếp với Gemini bằng giao diện thân thiện.

📌 **Không có tham số**, chỉ cần chạy hàm:
```excel
=NXA_Chat()