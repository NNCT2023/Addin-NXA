# 🔍 Hàm NXA_Extractor

## 📌 Cú pháp
`NXA_Extractor(prompt, keyword)`

## 🦾 Chức năng
Trích xuất thông tin quan trọng từ văn bản như tên, địa điểm, tổ chức...

| Tham số | Mô tả |
|---------|------|
| `prompt` | Văn bản cần phân tích |
| `keyword` | Từ khóa cần trích xuất |

📌 **Ví dụ**:
```excel
=NXA_Extractor(A2, "Địa điểm")